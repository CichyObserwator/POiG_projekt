CREATE TABLE Active (
    id int AUTO_INCREMENT NOT NULL,
    irritation varchar(255),
    PRIMARY KEY (id),
    substance varchar(255),
    substance_use varchar(255)
); 
INSERT INTO Active(id, irritation, substance, substance_use) VALUES (1, "tak","a","a");
INSERT INTO Active(id, irritation, substance, substance_use) VALUES (2, "tak","b","b");
INSERT INTO Active(id, irritation, substance, substance_use) VALUES (3, "nie","c","c");
INSERT INTO Active(id, irritation, substance, substance_use) VALUES (4, "nie","d","d");
CREATE TABLE Person (
    id int AUTO_INCREMENT NOT NULL,
    name varchar(255),
    gender varchar(255),
    age int,
    PRIMARY KEY (id),
    skin_type varchar(255)
);
INSERT INTO Person(id, name, gender, age, skin_type) VALUES (1, "karol","menzczyzna",26,"mokra");
INSERT INTO Person(id, name, gender, age, skin_type) VALUES (2, "daniel","menzczyzna",16,"mokra");
INSERT INTO Person(id, name, gender, age, skin_type) VALUES (3, "mariusz","menzczyzna",26,"mokra");
INSERT INTO Person(id, name, gender, age, skin_type) VALUES (4, "ewa","kobieta",46,"sucha");
INSERT INTO Person(id, name, gender, age, skin_type) VALUES (5, "katarzyna","kobieta",36,"sucha");
CREATE TABLE Consistency(
    id int AUTO_INCREMENT NOT NULL,
    consistency varchar(255),
    PRIMARY KEY (id)
); 
INSERT INTO Consistency(id, consistency) VALUES (1, "plyn");
INSERT INTO Consistency(id, consistency) VALUES (2, "krem");
CREATE TABLE Person_consistency (
    id int AUTO_INCREMENT NOT NULL,
    PRIMARY KEY (id),
    id_person int,
    FOREIGN KEY (id_person) REFERENCES Person(id),
    id_consistency int,
    FOREIGN KEY (id_consistency) REFERENCES Consistency(id)
);
INSERT INTO Person_consistency(id, id_person, id_consistency) VALUES (1, 1, 1);
INSERT INTO Person_consistency(id, id_person, id_consistency) VALUES (2, 2, 2);
INSERT INTO Person_consistency(id, id_person, id_consistency) VALUES (3, 3, 2);
INSERT INTO Person_consistency(id, id_person, id_consistency) VALUES (4, 4, 2);
INSERT INTO Person_consistency(id, id_person, id_consistency) VALUES (5, 5, 1);
CREATE TABLE Product (
    id int AUTO_INCREMENT NOT NULL,
    name varchar(255),
    frequency varchar(255),
    PRIMARY KEY (id),
    skin_type varchar(255),
    id_consistency int,
    FOREIGN KEY (id_consistency) REFERENCES Consistency(id),
    type varchar(255),
    product_use varchar(255)
);
INSERT INTO Product(id, name, frequency, skin_type, id_consistency, type, product_use) VALUES (1, "test" , "2 dni", "mokra", 1, "1", "1");
INSERT INTO Product(id, name, frequency, skin_type, id_consistency, type, product_use) VALUES (2, "test2" , "3 dni", "sucha", 2, "2", "2");
INSERT INTO Product(id, name, frequency, skin_type, id_consistency, type, product_use) VALUES (3, "test3" , "1 dni", "mokra", 2, "3", "3");
CREATE TABLE Product_active (
    id int AUTO_INCREMENT NOT NULL,
    PRIMARY KEY (id),
    id_active int,
    FOREIGN KEY (id_active) REFERENCES Active(id),
    id_product int,
    FOREIGN KEY (id_product) REFERENCES Product(id)
);
INSERT INTO Product_active(id, id_active, id_product) VALUES (1, 1, 1);
INSERT INTO Product_active(id, id_active, id_product) VALUES (2, 2, 2);
INSERT INTO Product_active(id, id_active, id_product) VALUES (3, 3, 3);
