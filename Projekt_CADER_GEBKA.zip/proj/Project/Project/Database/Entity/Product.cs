﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.Database.Entities
{
    /// <summary>
    /// Klasa służąca do przetrzymywania obiekótw z bazy danych z tabeli Product
    /// </summary>
    class Product
    {
        public sbyte? id { get; set; }
        public string name { get; set; }
        public string type { get; set; }
        public string use { get; set; }
        public string frequency { get; set; }
        public string skinType { get; set; }
        public sbyte id_consistency { get; set; }
        public Product(string name, string type, string use, string frequency, string skintype, sbyte id_consistency)
        {
            this.id = null;
            this.name = name;
            this.type = type;
            this.use = use;
            this.frequency = frequency;
            this.skinType = skintype;
            this.id_consistency = id_consistency;

        }
        public Product(Product product)
        {
            this.id = product.id;
            this.name = product.name;
            this.type = product.type;
            this.use = product.use;
            this.frequency = product.frequency;
            this.skinType = product.skinType;
            this.id_consistency = product.id_consistency;
        }
        public Product(MySqlDataReader rader)
        {
            this.id = sbyte.Parse(rader["id"].ToString());
            this.name = rader["name"].ToString();
            this.type = rader["type"].ToString();
            this.use = rader["product_use"].ToString();
            this.frequency = rader["frequency"].ToString();
            this.skinType = rader["skin_type"].ToString();
            this.id_consistency = sbyte.Parse(rader["id_consistency"].ToString());
        }
        public override string ToString()
        {
            return $"{this.id} : {this.name} : {this.type} : {this.use} : {this.frequency} : {this.skinType} : {this.id_consistency}";
        }
        public string ToInsert()
        {
            return $"('{this.name}' , '{this.type}' , '{this.use}' , '{this.frequency}' , '{this.skinType}' , '{this.id_consistency}')";
        }
    }
}
